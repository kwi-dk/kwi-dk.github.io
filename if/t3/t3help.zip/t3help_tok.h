#pragma ONCE

/*
 * This defines the tadsTokenizer object. It's similar to the library's Tokenizer,
 * but is slightly faster, and works a bit differently.
 * It works around a bug that causes crashes when regex'ing long strings,
 * by tokenizing one token at a time.
 */

enum ptokCode;    // pretokenize: code
enum ptokComment; // pretokenize: comment
// Furthermore, during pretokenize tokSString and tokDString tokens may be read.

enum tokPreproc;	// A preprocessor directive
enum tokPreprocEnd; // The end of the directive.
enum tokSymbol;	// An identifier.
enum tokPunct;	// ':', '.', ',', '@', etc.
enum tokBraceB;   // '{'
enum tokBraceE;	// '}'
enum tokParenB;	// '('
enum tokParenE;	// ')'
enum tokAssign;	// '='
enum tokSemicolon;// ';'
enum tokOperator;	// +, -, *, /, %, &, |, &&, ||, and, or, xor, !=, ==, <, >,  etc...
enum tokSString;	// A single-quoted string.
enum tokDString;	// A double-quoted string.
enum tokNumber;	// A number.
enum tokEOF;	// End of file.

// Reserved words:
enum	rwCase,	rwClass,	rwDictionary,	rwElse,	rwEnum,	rwExport,	rwFunction,
	rwIf,		rwIntrinsic,rwModify,		rwNew,	rwProperty,	rwReplace,	rwStatic,
	rwSwitch,	rwTemplate,	rwToken,		rwTransient;

function RemoveNewlines(s) {
 return s.findReplace('\n', ' ', ReplaceAll);
}

function Trim(s) { // Cleans leading and trailing whitespace.
 local i, j;
 local len = s.length();
 for (i = 1; i <= len; i++) if (s.toUnicode(i) > 32) break;
 for (j = len; j >= i; j--) if (s.toUnicode(j) > 32) break;
 return s.substr(i, j - i + 1);
}

tadsTokenizer: object { 
 parent = nil; // This is just an arbitrary object, except that it MUST provide an Error(msg) method.
 
 reservedWords = static (reservedWords = new LookupTable(16, 16),
		reservedWords['case']		= rwCase,
		reservedWords['class']		= rwClass,
		reservedWords['dictionary']	= rwDictionary,
		reservedWords['else']		= rwElse,
		reservedWords['enum']		= rwEnum,
		reservedWords['export']		= rwExport,
		reservedWords['function']	= rwFunction,
		reservedWords['if']		= rwIf,
		reservedWords['intrinsic']	= rwIntrinsic,
		reservedWords['modify']		= rwModify,
		reservedWords['new']		= rwNew,
		reservedWords['property']	= rwProperty,
		reservedWords['replace']	= rwReplace,
		reservedWords['static']		= rwStatic,
		reservedWords['switch']		= rwSwitch,
		reservedWords['template']	= rwTemplate,
		reservedWords['token']		= rwToken,
		reservedWords['transient']	= rwTransient,
		reservedWords);
 normalrules = static [
  [new RexPattern('<space|newline>+'),				nil,		&cvtWhitespace],
  [new RexPattern('(^|<newline>)#'),				nil,		&cvtPreprocStart],
  [new RexPattern('[]-^+*/%![&|<>~:?]|<vbar><vbar>|>>|>>=|<&&|is in|not in|++|--|\<<|...>|((<\<<>|[!=|&+-*/%^])=)'), tokOperator, &cvtNormal],
  [new RexPattern('[{]'),						tokBraceB,	&cvtNormal],
  [new RexPattern('[}]'),						tokBraceE,	&cvtNormal],
  [new RexPattern('[(]'),						tokParenB,	&cvtNormal],
  [new RexPattern('[)]'),						tokParenE,	&cvtNormal],
  [new RexPattern('[=]'),						tokAssign,	&cvtNormal],
  [new RexPattern('[;]'),						tokSemicolon,&cvtNormal],
  [new RexPattern('[.,:@]'),						tokPunct,	&cvtNormal],
  [new RexPattern('[a-zA-Z_][a-zA-Z0-9_]*'),			tokSymbol,	&cvtSymbol],
  [new RexPattern('[0-9]+'),						tokNumber,	&cvtNormal]
 ];
 preprocrules = static [
  [new RexPattern('(<^newline>|(\\<newline>))+'),		nil,		&cvtPreprocCont],
  [new RexPattern('<newline>'),					nil,		&cvtPreprocEnd]
 ];
 rules = static (rules = normalrules);
 rulescnt = static (normalrules.length());
 
 whitespace = ''; // Yes, we keep track of the whitespace.
 
 cvtPreprocStart(txt, typ) {
  toks.append(tokPreproc); toks.append(nil);
  toks.append(whitespace + txt); whitespace = ''; 
  rules = preprocrules; // Simply replace the entire rule set with one that looks for newlines.
  rulescnt = preprocrules.length();
 }
 cvtPreprocCont(txt, typ) {   toks.append(tokPreproc); toks.append(nil); toks.append(txt); }
 cvtPreprocEnd(txt, typ) {
  rules = normalrules; // Back to normal rules.
  rulescnt = normalrules.length();
  
  toks.append(tokPreprocEnd); toks.append(nil); toks.append(txt);
 }

 cvtWhitespace(txt, typ) {
  whitespace = txt;
 }
 
 cvtSymbol(txt, typ) {
  local rw = reservedWords[txt];
  if (rw) toks.append(rw); else toks.append(typ);
  toks.append(txt);
  toks.append(whitespace + txt); whitespace = '';
 }
 
 cvtNormal(txt, typ) {
  toks.append(typ);
  toks.append(txt);
  toks.append(whitespace + txt); whitespace = '';
 }

 toks = nil;	// List of token-typ, value, original-text groups.
 comments = nil;	// List of tokenindex, comment-string groups.
 str  = nil;	// String to tokenize.
 ptoks = nil;	// This holds the pretokenize results.
 
// '\n *   TADS 3 Library \n *   \n *   This module defines \n *   blah blah: rooms.  \n '
 rexCommentKeepBreaks	= static new RexPattern('<space>*<newline><space>*<star><space>*');
// '\nTADS 3 Library\n\nThis module defines\nblah blah: rooms.  \n ' 
 rexCommentCleanBreaks	= static new RexPattern('<space>*<newline>([^.]<space>*<^newline>)');
// ' TADS 3 Library \nThis module defines blah blah: rooms.  \n '

 pretokenize() {	// Split the text into comments, strings and everything else.
  local x, ptok, ptokstr;
  local strlen = str.length();
  local quote = str.toUnicode(1); // Not neccessarily a quotation mark, but - eh.
  
  // We do some stuff with unicode numbers here. The numbers are:
  // '"' = 34,  '\'' = 39,  '/' = 47,  '\' = 92
  
  if (str.substr(1, 2) == '/*') {
   ptok = ptokComment;
   x = str.find('*/');
   if (!x) return nil; // We need more text in the buffer.
   ptokstr = str.substr(3, x - 3);
   x++; // Also include the final '/'.

   if (ptokstr.length() > 5000) {
    parent.Error('Warning: Comment exceeded the RegExp limit by ' + (ptokstr.length() - 5000) + ' characters and was truncated to 5000.');
    ptokstr = ptokstr.substr(1, 5000);
   }  
   ptokstr = rexReplace(rexCommentKeepBreaks, ptokstr, '\n', ReplaceAll);
   ptokstr = rexReplace(rexCommentCleanBreaks, ptokstr, ' %1', ReplaceAll);
   ptokstr = Trim(ptokstr);   
   ptokstr = ptokstr.findReplace('\n', '\b', ReplaceAll);
  } 
  else if (quote == 39) ptok = tokSString;
  else if (quote == 34) ptok = tokDString;
  else {
   ptok = ptokCode;
   for (x = 2; x <= strlen && str.toUnicode(x) not in (47, 39, 34); x++);
   x--;
// ptokstr = nil
  }
 
  if (ptok is in (tokSString, tokDString)) {
   local i;
   for (x = 2; (i = str.toUnicode(x)) != quote; x++) {
    if (i == 92) x++; // Skip the special char.
    if (x >= strlen) return nil; // Need more text!
   }
// ptokstr = nil
  }

  ptoks.append(ptok);
  ptoks.append(ptokstr);
  ptoks.append(str.substr(1, x)); // Also save original text.
  str = str.substr(x + 1);
  return true;
 }
 
 /*
  *  Note that toks doesn't contain lists in this implementation. Instead,
  *  it contains three entries per token: type (enum), value and text.
  */
 
 tokenize() { // Tokenizes ALL the "pretokens".
  local cur, match, i, ptokidx;
  local ptokslen = ptoks.length();
  toks	= new Vector(2560);
  comments	= new Vector(2560);
  
  TokenizeLoop:
  for (ptokidx = 1; ptokidx < ptokslen; ptokidx += 3) {
   if (ptoks[ptokidx] == ptokComment) { comments.append(toks.length() + 1); comments.append(ptoks[ptokidx + 1]); }
   else if (ptoks[ptokidx] == ptokCode) {
    local str = ptoks[ptokidx + 2];
    CodeTokenizeLoop:
    while (str != '') {
     for (i = 1; i <= rulescnt; i++) {
      cur = rules[i];
      match = rexMatch(cur[1], str);
   
      if (match != nil && match > 0) {
       self.(cur[3])(str.substr(1, match), cur[2]);
       str = str.substr(match + 1);
       continue CodeTokenizeLoop;
      }
       // No luck with this rule, try the next one.
     }
     // No luck with any rules.
     parent.Error('Tokenizer error:\n--&gt; <TT>' + RemoveNewlines(str.substr(1, 50)) + '</TT>');
     break TokenizeLoop;
    }
   } else { // dstring or sstring
    toks.append(ptoks[ptokidx]);
    toks.append(ptoks[ptokidx + 1]);
    toks.append(ptoks[ptokidx + 2]);
   }
  }
  // Done. Dispose of the ptoks.
  ptoks = nil;
 }
}
/////////////// TOKENIZER END ///////////////