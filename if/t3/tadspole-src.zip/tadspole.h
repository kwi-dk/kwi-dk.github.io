#charset "us-ascii"

/*
 *   Copyright 2003-04 Soren J. Lovborg.
 *  
 *   Permission is hereby granted, free of charge, to any person obtaining a
 *   copy of this software and associated documentation files (the "Software"), 
 *   to deal in the Software without restriction, including without limitation 
 *   the rights to use, copy, modify, merge, publish, distribute, sublicense,
 *   and/or sell copies of the Software, and to permit persons to whom the
 *   Software is furnished to do so, subject to the following conditions:
 *  
 *   The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.
 *  
 *   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *   FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 *   DEALINGS IN THE SOFTWARE.
 */


#define false nil

#define T3ImageHeader 'T3-image\015\012\032'

// Header field constants.
#define UINT1   FmtUInt8
#define UINT2   FmtUInt16LE
#define UINT4   FmtInt32LE

#define FMTMASK    0x00FFFF

#define DECIMAL    0x010000 // Display flag: Don't display number as hex.
#define STRING     0x020000
#define STRING1    (STRING | UINT1) // A string. One byte length followed by up to 255 of UTF-8 characters.
#define STRING2    (STRING | UINT2) // A string. TWO byte length.
#define STRING4    (STRING | UINT4) // A string. FOUR byte length.
#define XOR_FF     0x040000 // String-bytes are XOR'ed with 0xFF.
#define DATAHOLDER 0x100000 // A TADS3  5-bytes dataholder. Loaded as a ByteArray.

#define DINT2 (UINT2 | DECIMAL)
#define DINT4 (UINT4 | DECIMAL)

